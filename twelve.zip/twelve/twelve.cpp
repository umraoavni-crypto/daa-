

#include <iostream>
#include <climits>
using namespace std;

void matrixChainMultiplication(int p[], int n) {
    int dp[100][100];

    // Cost of multiplying one matrix is zero
    for (int i = 1; i < n; i++) {
        dp[i][i] = 0;
    }

    // len is the chain length
    for (int len = 2; len < n; len++) {
        for (int i = 1; i < n - len + 1; i++) {
            int j = i + len - 1;
            dp[i][j] = INT_MAX;

            for (int k = i; k < j; k++) {
                int cost = dp[i][k] + dp[k + 1][j]
                         + p[i - 1] * p[k] * p[j];

                if (cost < dp[i][j]) {
                    dp[i][j] = cost;
                }
            }
        }
    }

    cout << "Minimum number of scalar multiplications: "
         << dp[1][n - 1] << endl;
}

int main() {
    int n, p[100];

    cout << "Enter number of matrices: ";
    cin >> n;

    if (n <= 0 || n >= 100) {
        cout << "Invalid number of matrices." << endl;
        return 1;
    }

    cout << "Enter " << n + 1
         << " dimensions: ";
    for (int i = 0; i <= n; i++) {
        cin >> p[i];
    }

    matrixChainMultiplication(p, n + 1);

    return 0;
}
