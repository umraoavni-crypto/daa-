
#include <iostream>
#include <vector>
#include <climits>
using namespace std;

struct Edge {
    int src, dest, weight;
};

void bellmanFord(int V, int E, vector<Edge>& edges, int source) {
    vector<long long> dist(V, LLONG_MAX);

    dist[source] = 0;

    // Relax all edges V-1 times
    for (int i = 1; i <= V - 1; i++) {
        bool updated = false;

        for (const Edge& edge : edges) {
            int u = edge.src;
            int v = edge.dest;
            int w = edge.weight;

            if (dist[u] != LLONG_MAX &&
                dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                updated = true;
            }
        }

        // Stop early if no distance changes
        if (!updated)
            break;
    }

    // Check for a negative-weight cycle
    for (const Edge& edge : edges) {
        int u = edge.src;
        int v = edge.dest;
        int w = edge.weight;

        if (dist[u] != LLONG_MAX &&
            dist[u] + w < dist[v]) {
            cout << "Negative-weight cycle detected!\n";
            return;
        }
    }

    // Print shortest distances
    cout << "Vertex\tShortest Distance from Source\n";
    for (int i = 0; i < V; i++) {
        cout << i << "\t";

        if (dist[i] == LLONG_MAX)
            cout << "INF";
        else
            cout << dist[i];

        cout << '\n';
    }
}

int main() {
    int V, E;

    cout << "Enter number of vertices and edges: ";
    cin >> V >> E;

    vector<Edge> edges(E);

    cout << "Enter edges (source destination weight):\n";
    for (int i = 0; i < E; i++) {
        cin >> edges[i].src
            >> edges[i].dest
            >> edges[i].weight;
    }

    int source;
    cout << "Enter source vertex: ";
    cin >> source;

    if (V <= 0 || source < 0 || source >= V) {
        cout << "Invalid number of vertices or source.\n";
        return 1;
    }

    for (const Edge& edge : edges) {
        if (edge.src < 0 || edge.src >= V ||
            edge.dest < 0 || edge.dest >= V) {
            cout << "Invalid edge endpoint.\n";
            return 1;
        }
    }

    bellmanFord(V, E, edges, source);

    return 0;
}
