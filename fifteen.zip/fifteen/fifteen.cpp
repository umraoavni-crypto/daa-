

#include <iostream>
#include <vector>
using namespace std;

void printBoard(const vector<vector<int>>& board, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << (board[i][j] ? "Q " : ". ");
        }
        cout << endl;
    }
}

bool isSafe(const vector<vector<int>>& board,
            int row, int col, int n) {

    // Check the same column in previous rows
    for (int i = 0; i < row; i++) {
        if (board[i][col])
            return false;
    }

    // Check upper-left diagonal
    for (int i = row - 1, j = col - 1;
         i >= 0 && j >= 0; i--, j--) {
        if (board[i][j])
            return false;
    }

    // Check upper-right diagonal
    for (int i = row - 1, j = col + 1;
         i >= 0 && j < n; i--, j++) {
        if (board[i][j])
            return false;
    }

    return true;
}

bool solveNQueens(vector<vector<int>>& board,
                  int row, int n) {

    // All queens have been placed
    if (row == n)
        return true;

    // Try placing a queen in each column
    for (int col = 0; col < n; col++) {
        if (isSafe(board, row, col, n)) {
            board[row][col] = 1;

            if (solveNQueens(board, row + 1, n))
                return true;

            // Backtrack
            board[row][col] = 0;
        }
    }

    return false;
}

int main() {
    int n;

    cout << "Enter the value of N: ";
    cin >> n;

    if (n <= 0) {
        cout << "N must be a positive integer.\n";
        return 1;
    }

    vector<vector<int>> board(n, vector<int>(n, 0));

    if (solveNQueens(board, 0, n)) {
        cout << "Solution to " << n << "-Queens problem:\n";
        printBoard(board, n);
    } else {
        cout << "No solution exists for N = " << n << ".\n";
    }

    return 0;
}

